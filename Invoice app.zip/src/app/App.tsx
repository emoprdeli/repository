import { Invoice } from './components/Invoice';

export default function App() {
  return (
    <div className="size-full">
      <Invoice />
    </div>
  );
}
