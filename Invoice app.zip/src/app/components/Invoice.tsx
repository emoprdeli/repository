import { useState, useEffect } from 'react';
import { Plus, Trash2, Printer, Save, ChevronDown, Archive, FolderOpen, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';

interface LineItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
}

type DocumentType = 'invoice' | 'offer';
type Language = 'cs' | 'en';
type Currency = 'CZK' | 'CAD';

interface SupplierData {
  id: string;
  name: string;
  address: string;
  email: string;
  phone: string;
  ico: string;
}

interface ClientData {
  id: string;
  name: string;
  address: string;
  email: string;
  ico: string;
  dic: string;
}

interface ArchivedInvoice {
  id: string;
  documentType: DocumentType;
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  companyName: string;
  companyAddress: string;
  companyEmail: string;
  companyPhone: string;
  companyICO: string;
  clientName: string;
  clientAddress: string;
  clientEmail: string;
  clientICO: string;
  clientDIC: string;
  lineItems: LineItem[];
  notes: string;
  signature: string;
  showSignature: boolean;
  archivedDate: string;
}

const translations = {
  cs: {
    invoice: 'FAKTURA',
    offer: 'NABÍDKA',
    invoiceButton: 'Faktura',
    offerButton: 'Nabídka',
    printInvoice: 'Tisknout fakturu',
    printOffer: 'Tisknout nabídku',
    issueDate: 'Datum vystavení',
    dueDate: 'Datum splatnosti',
    date: 'Datum',
    from: 'Od',
    to: 'Pro',
    ico: 'IČO:',
    dic: 'DIČ:',
    saveSupplier: 'Uložit dodavatele',
    selectSupplier: 'Vybrat dodavatele',
    noSavedSuppliers: 'Žádní uložení dodavatelé',
    saveClient: 'Uložit klienta',
    selectClient: 'Vybrat klienta',
    noSavedClients: 'Žádní uložení klienti',
    description: 'Popis služby',
    quantity: 'Množ.',
    unitPrice: 'Cena/ks',
    total: 'Celkem',
    addItem: 'Přidat položku',
    itemPlaceholder: 'Popis položky',
    subtotal: 'Mezisoučet:',
    totalPrice: 'Cena celkem:',
    notes: 'Poznámky',
    notesPlaceholder: 'Dodatečné poznámky nebo platební podmínky...',
    showSignature: 'Zobrazit sekci s podpisem',
    supplierSignature: 'Podpis dodavatele',
    signatureSpace: 'Prostor pro podpis',
    removeSignature: 'Odstranit podpis',
    archiveInvoice: 'Uložit do archivu',
    archivedInvoices: 'Archivované faktury',
    noArchivedInvoices: 'Žádné archivované faktury',
    deleteSupplierConfirm: 'Opravdu chcete odstranit tohoto dodavatele?',
    deleteClientConfirm: 'Opravdu chcete odstranit tohoto klienta?',
    deleteArchivedConfirm: 'Opravdu chcete odstranit tuto archivovanou fakturu?',
    supplierExists: 'Dodavatel s tímto názvem nebo IČO již existuje.',
    clientExists: 'Klient s tímto jménem nebo IČO již existuje.',
    archiveSuccess: 'Faktura byla úspěšně archivována.',
    signature: 'Podpis',
  },
  en: {
    invoice: 'INVOICE',
    offer: 'QUOTE',
    invoiceButton: 'Invoice',
    offerButton: 'Quote',
    printInvoice: 'Print invoice',
    printOffer: 'Print quote',
    issueDate: 'Issue date',
    dueDate: 'Due date',
    date: 'Date',
    from: 'From',
    to: 'To',
    ico: 'Company ID:',
    dic: 'Tax ID:',
    saveSupplier: 'Save supplier',
    selectSupplier: 'Select supplier',
    noSavedSuppliers: 'No saved suppliers',
    saveClient: 'Save client',
    selectClient: 'Select client',
    noSavedClients: 'No saved clients',
    description: 'Description',
    quantity: 'Qty.',
    unitPrice: 'Unit price',
    total: 'Total',
    addItem: 'Add item',
    itemPlaceholder: 'Item description',
    subtotal: 'Subtotal:',
    totalPrice: 'Total amount:',
    notes: 'Notes',
    notesPlaceholder: 'Additional notes or payment terms...',
    showSignature: 'Show signature section',
    supplierSignature: 'Supplier signature',
    signatureSpace: 'Signature space',
    removeSignature: 'Remove signature',
    archiveInvoice: 'Save to archive',
    archivedInvoices: 'Archived invoices',
    noArchivedInvoices: 'No archived invoices',
    deleteSupplierConfirm: 'Are you sure you want to delete this supplier?',
    deleteClientConfirm: 'Are you sure you want to delete this client?',
    deleteArchivedConfirm: 'Are you sure you want to delete this archived invoice?',
    supplierExists: 'A supplier with this name or Company ID already exists.',
    clientExists: 'A client with this name or Company ID already exists.',
    archiveSuccess: 'Invoice has been successfully archived.',
    signature: 'Signature',
  },
};

export function Invoice() {
  const [language, setLanguage] = useState<Language>('cs');
  const [currency, setCurrency] = useState<Currency>('CZK');
  const [documentType, setDocumentType] = useState<DocumentType>('invoice');

  const t = translations[language];
  
  // Supplier data
  const [companyName, setCompanyName] = useState('Název vaší společnosti');
  const [companyAddress, setCompanyAddress] = useState('Ulice 123, Praha 1, 110 00');
  const [companyEmail, setCompanyEmail] = useState('kontakt@firma.cz');
  const [companyPhone, setCompanyPhone] = useState('+420 123 456 789');
  const [companyICO, setCompanyICO] = useState('12345678');

  // Client data
  const [clientName, setClientName] = useState('Jméno klienta');
  const [clientAddress, setClientAddress] = useState('Ulice 456, Praha 2, 120 00');
  const [clientEmail, setClientEmail] = useState('klient@email.cz');
  const [clientICO, setClientICO] = useState('87654321');
  const [clientDIC, setClientDIC] = useState('CZ87654321');

  // Saved suppliers and clients
  const [savedSuppliers, setSavedSuppliers] = useState<SupplierData[]>([]);
  const [savedClients, setSavedClients] = useState<ClientData[]>([]);
  const [showSupplierDropdown, setShowSupplierDropdown] = useState(false);
  const [showClientDropdown, setShowClientDropdown] = useState(false);

  // Archived invoices
  const [archivedInvoices, setArchivedInvoices] = useState<ArchivedInvoice[]>([]);
  const [showArchivedDropdown, setShowArchivedDropdown] = useState(false);

  const [invoiceNumber, setInvoiceNumber] = useState('FAK-001');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );

  const [lineItems, setLineItems] = useState<LineItem[]>([
    { id: '1', description: 'Služba nebo produkt', quantity: 1, rate: 1000 },
  ]);

  const [notes, setNotes] = useState('Děkujeme za vaši důvěru!');
  const [signature, setSignature] = useState<string>('');
  const [showSignature, setShowSignature] = useState(true);

  const addLineItem = () => {
    setLineItems([
      ...lineItems,
      {
        id: Date.now().toString(),
        description: '',
        quantity: 1,
        rate: 0,
      },
    ]);
  };

  const removeLineItem = (id: string) => {
    setLineItems(lineItems.filter((item) => item.id !== id));
  };

  const updateLineItem = (id: string, field: keyof LineItem, value: string | number) => {
    setLineItems(
      lineItems.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      )
    );
  };

  const subtotal = lineItems.reduce(
    (sum, item) => sum + item.quantity * item.rate,
    0
  );

  const handlePrint = () => {
    window.print();
  };

  const formatCurrency = (amount: number) => {
    if (currency === 'CZK') {
      return `${amount.toFixed(2).replace('.', ',')} Kč`;
    } else {
      return `$${amount.toFixed(2)}`;
    }
  };

  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSignature(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Load saved suppliers and clients from local storage
  useEffect(() => {
    const savedSuppliers = JSON.parse(localStorage.getItem('savedSuppliers') || '[]');
    const savedClients = JSON.parse(localStorage.getItem('savedClients') || '[]');
    setSavedSuppliers(savedSuppliers);
    setSavedClients(savedClients);
  }, []);

  // Save current supplier to local storage
  const saveSupplier = () => {
    // Check if supplier already exists (by name or ICO)
    const exists = savedSuppliers.some(
      (s) => s.name === companyName || s.ico === companyICO
    );

    if (exists) {
      alert(t.supplierExists);
      return;
    }

    const newSupplier: SupplierData = {
      id: Date.now().toString(),
      name: companyName,
      address: companyAddress,
      email: companyEmail,
      phone: companyPhone,
      ico: companyICO,
    };
    const updatedSuppliers = [...savedSuppliers, newSupplier];
    setSavedSuppliers(updatedSuppliers);
    localStorage.setItem('savedSuppliers', JSON.stringify(updatedSuppliers));
  };

  // Save current client to local storage
  const saveClient = () => {
    // Check if client already exists (by name or ICO)
    const exists = savedClients.some(
      (c) => c.name === clientName || c.ico === clientICO
    );

    if (exists) {
      alert(t.clientExists);
      return;
    }

    const newClient: ClientData = {
      id: Date.now().toString(),
      name: clientName,
      address: clientAddress,
      email: clientEmail,
      ico: clientICO,
      dic: clientDIC,
    };
    const updatedClients = [...savedClients, newClient];
    setSavedClients(updatedClients);
    localStorage.setItem('savedClients', JSON.stringify(updatedClients));
  };

  // Delete supplier
  const deleteSupplier = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(t.deleteSupplierConfirm)) {
      const updatedSuppliers = savedSuppliers.filter((s) => s.id !== id);
      setSavedSuppliers(updatedSuppliers);
      localStorage.setItem('savedSuppliers', JSON.stringify(updatedSuppliers));
    }
  };

  // Delete client
  const deleteClient = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(t.deleteClientConfirm)) {
      const updatedClients = savedClients.filter((c) => c.id !== id);
      setSavedClients(updatedClients);
      localStorage.setItem('savedClients', JSON.stringify(updatedClients));
    }
  };

  // Select supplier from dropdown
  const selectSupplier = (supplier: SupplierData) => {
    setCompanyName(supplier.name);
    setCompanyAddress(supplier.address);
    setCompanyEmail(supplier.email);
    setCompanyPhone(supplier.phone);
    setCompanyICO(supplier.ico);
    setShowSupplierDropdown(false);
  };

  // Select client from dropdown
  const selectClient = (client: ClientData) => {
    setClientName(client.name);
    setClientAddress(client.address);
    setClientEmail(client.email);
    setClientICO(client.ico);
    setClientDIC(client.dic);
    setShowClientDropdown(false);
  };

  // Archive invoice
  const archiveInvoice = () => {
    const archivedInvoice: ArchivedInvoice = {
      id: Date.now().toString(),
      documentType,
      invoiceNumber,
      invoiceDate,
      dueDate,
      companyName,
      companyAddress,
      companyEmail,
      companyPhone,
      companyICO,
      clientName,
      clientAddress,
      clientEmail,
      clientICO,
      clientDIC,
      lineItems,
      notes,
      signature,
      showSignature,
      archivedDate: new Date().toISOString().split('T')[0],
    };
    const updatedArchivedInvoices = [...archivedInvoices, archivedInvoice];
    setArchivedInvoices(updatedArchivedInvoices);
    localStorage.setItem('archivedInvoices', JSON.stringify(updatedArchivedInvoices));
    alert(t.archiveSuccess);
  };

  // Load archived invoice
  const loadArchivedInvoice = (invoice: ArchivedInvoice) => {
    setDocumentType(invoice.documentType);
    setInvoiceNumber(invoice.invoiceNumber);
    setInvoiceDate(invoice.invoiceDate);
    setDueDate(invoice.dueDate);
    setCompanyName(invoice.companyName);
    setCompanyAddress(invoice.companyAddress);
    setCompanyEmail(invoice.companyEmail);
    setCompanyPhone(invoice.companyPhone);
    setCompanyICO(invoice.companyICO);
    setClientName(invoice.clientName);
    setClientAddress(invoice.clientAddress);
    setClientEmail(invoice.clientEmail);
    setClientICO(invoice.clientICO);
    setClientDIC(invoice.clientDIC);
    setLineItems(invoice.lineItems);
    setNotes(invoice.notes);
    setSignature(invoice.signature);
    setShowSignature(invoice.showSignature);
    setShowArchivedDropdown(false);
  };

  // Delete archived invoice
  const deleteArchivedInvoice = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(t.deleteArchivedConfirm)) {
      const updatedArchivedInvoices = archivedInvoices.filter((i) => i.id !== id);
      setArchivedInvoices(updatedArchivedInvoices);
      localStorage.setItem('archivedInvoices', JSON.stringify(updatedArchivedInvoices));
    }
  };

  // Load archived invoices from local storage
  useEffect(() => {
    const archivedInvoices = JSON.parse(localStorage.getItem('archivedInvoices') || '[]');
    setArchivedInvoices(archivedInvoices);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 p-8 print:p-0 print:bg-white">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-4 print:hidden">
          <div className="flex gap-2">
            <Button
              onClick={() => setDocumentType('invoice')}
              variant={documentType === 'invoice' ? 'default' : 'outline'}
            >
              {t.invoiceButton}
            </Button>
            <Button
              onClick={() => setDocumentType('offer')}
              variant={documentType === 'offer' ? 'default' : 'outline'}
            >
              {t.offerButton}
            </Button>
          </div>
          <div className="flex gap-2 items-center">
            <div className="flex gap-1 border border-slate-300 rounded-lg p-1">
              <Button
                onClick={() => {
                  setLanguage('cs');
                  setCurrency('CZK');
                }}
                variant={language === 'cs' ? 'default' : 'ghost'}
                size="sm"
                className="gap-2"
              >
                <Globe className="size-4" />
                CZ
              </Button>
              <Button
                onClick={() => {
                  setLanguage('en');
                  setCurrency('CAD');
                }}
                variant={language === 'en' ? 'default' : 'ghost'}
                size="sm"
                className="gap-2"
              >
                <Globe className="size-4" />
                EN
              </Button>
            </div>
            <Button onClick={handlePrint} className="gap-2">
              <Printer className="size-4" />
              {documentType === 'invoice' ? t.printInvoice : t.printOffer}
            </Button>
          </div>
        </div>

        <Card className="bg-white shadow-lg a4-page border-0">
          {/* Modern Header with colored accent */}
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 rounded-t-lg print:rounded-none">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-4xl font-bold mb-1 tracking-tight">
                  {documentType === 'invoice' ? t.invoice : t.offer}
                </h1>
                {documentType === 'invoice' && (
                  <div className="text-blue-100 text-sm">
                    <Input
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      className="bg-transparent border-0 px-0 text-white placeholder:text-blue-200 focus-visible:ring-0 font-semibold w-32"
                    />
                  </div>
                )}
              </div>
              {documentType === 'invoice' && (
                <div className="text-right text-sm space-y-1">
                  <div className="text-blue-100">{t.issueDate}</div>
                  <Input
                    type="date"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="bg-white/10 border-white/20 text-white text-right px-2 h-8 text-sm focus-visible:ring-white/30"
                  />
                  <div className="text-blue-100 mt-2">{t.dueDate}</div>
                  <Input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="bg-white/10 border-white/20 text-white text-right px-2 h-8 text-sm focus-visible:ring-white/30"
                  />
                </div>
              )}
              {documentType === 'offer' && (
                <div className="text-right text-sm">
                  <div className="text-blue-100">{t.date}</div>
                  <Input
                    type="date"
                    value={invoiceDate}
                    onChange={(e) => setInvoiceDate(e.target.value)}
                    className="bg-white/10 border-white/20 text-white text-right px-2 h-8 text-sm focus-visible:ring-white/30"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="p-6">
            {/* Contact Information Grid */}
            <div className="grid grid-cols-2 gap-6 mb-6">
              {/* From Section */}
              <div>
                <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-2">{t.from}</div>
                <div className="space-y-1">
                  <Input
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="font-semibold text-base border-0 px-0 h-auto focus-visible:ring-0 text-slate-900"
                  />
                  <Input
                    value={companyAddress}
                    onChange={(e) => setCompanyAddress(e.target.value)}
                    className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-600"
                  />
                  <Input
                    value={companyEmail}
                    onChange={(e) => setCompanyEmail(e.target.value)}
                    className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-600"
                  />
                  <Input
                    value={companyPhone}
                    onChange={(e) => setCompanyPhone(e.target.value)}
                    className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-600"
                  />
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-xs text-slate-500 font-medium">{t.ico}</span>
                    <Input
                      value={companyICO}
                      onChange={(e) => setCompanyICO(e.target.value)}
                      className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-700 w-auto"
                    />
                  </div>
                </div>
                <div className="mt-4 print:hidden">
                  <Button
                    onClick={saveSupplier}
                    variant="outline"
                    className="gap-2"
                  >
                    <Save className="size-4" />
                    {t.saveSupplier}
                  </Button>
                </div>
                <div className="relative mt-2 print:hidden">
                  <Button
                    onClick={() => setShowSupplierDropdown(!showSupplierDropdown)}
                    variant="outline"
                    className="gap-2"
                  >
                    <ChevronDown className="size-4" />
                    {t.selectSupplier}
                  </Button>
                  {showSupplierDropdown && (
                    <div className="absolute left-0 top-full bg-white border border-slate-300 shadow-lg z-10 w-full max-h-60 overflow-y-auto rounded-md">
                      {savedSuppliers.length === 0 ? (
                        <div className="px-4 py-3 text-sm text-slate-500 text-center">
                          {t.noSavedSuppliers}
                        </div>
                      ) : (
                        savedSuppliers.map((supplier) => (
                          <div
                            key={supplier.id}
                            className="px-4 py-2 cursor-pointer hover:bg-slate-100 flex justify-between items-center group"
                            onClick={() => selectSupplier(supplier)}
                          >
                            <span className="text-sm">{supplier.name}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => deleteSupplier(supplier.id, e)}
                              className="opacity-0 group-hover:opacity-100 h-7 w-7 p-0"
                            >
                              <Trash2 className="size-3.5 text-red-500" />
                            </Button>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* To Section */}
              <div>
                <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-2">{t.to}</div>
                <div className="space-y-1">
                  <Input
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="font-semibold text-base border-0 px-0 h-auto focus-visible:ring-0 text-slate-900"
                  />
                  <Input
                    value={clientAddress}
                    onChange={(e) => setClientAddress(e.target.value)}
                    className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-600"
                  />
                  <Input
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-600"
                  />
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-xs text-slate-500 font-medium">{t.ico}</span>
                    <Input
                      value={clientICO}
                      onChange={(e) => setClientICO(e.target.value)}
                      className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-700 w-auto"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-xs text-slate-500 font-medium">{t.dic}</span>
                    <Input
                      value={clientDIC}
                      onChange={(e) => setClientDIC(e.target.value)}
                      className="text-sm border-0 px-0 h-auto focus-visible:ring-0 text-slate-700 w-auto"
                    />
                  </div>
                </div>
                <div className="mt-4 print:hidden">
                  <Button
                    onClick={saveClient}
                    variant="outline"
                    className="gap-2"
                  >
                    <Save className="size-4" />
                    {t.saveClient}
                  </Button>
                </div>
                <div className="relative mt-2 print:hidden">
                  <Button
                    onClick={() => setShowClientDropdown(!showClientDropdown)}
                    variant="outline"
                    className="gap-2"
                  >
                    <ChevronDown className="size-4" />
                    {t.selectClient}
                  </Button>
                  {showClientDropdown && (
                    <div className="absolute left-0 top-full bg-white border border-slate-300 shadow-lg z-10 w-full max-h-60 overflow-y-auto rounded-md">
                      {savedClients.length === 0 ? (
                        <div className="px-4 py-3 text-sm text-slate-500 text-center">
                          {t.noSavedClients}
                        </div>
                      ) : (
                        savedClients.map((client) => (
                          <div
                            key={client.id}
                            className="px-4 py-2 cursor-pointer hover:bg-slate-100 flex justify-between items-center group"
                            onClick={() => selectClient(client)}
                          >
                            <span className="text-sm">{client.name}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => deleteClient(client.id, e)}
                              className="opacity-0 group-hover:opacity-100 h-7 w-7 p-0"
                            >
                              <Trash2 className="size-3.5 text-red-500" />
                            </Button>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Line Items */}
            <div className="mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="border-b-2 border-slate-300">
                    <th className="text-left py-3 px-2 font-semibold text-slate-600 uppercase tracking-wide text-xs">
                      {t.description}
                    </th>
                    <th className="text-center py-3 px-2 font-semibold text-slate-600 uppercase tracking-wide text-xs w-20">{t.quantity}</th>
                    <th className="text-right py-3 px-2 font-semibold text-slate-600 uppercase tracking-wide text-xs w-28">{t.unitPrice}</th>
                    <th className="text-right py-3 px-2 font-semibold text-slate-600 uppercase tracking-wide text-xs w-32">{t.total}</th>
                    <th className="w-10 print:hidden"></th>
                  </tr>
                </thead>
                <tbody>
                  {lineItems.map((item, index) => (
                    <tr key={item.id} className="border-b border-slate-100">
                      <td className="py-3 px-2 align-top">
                        <textarea
                          value={item.description}
                          onChange={(e) =>
                            updateLineItem(item.id, 'description', e.target.value)
                          }
                          placeholder={t.itemPlaceholder}
                          rows={1}
                          className="w-full text-sm border-0 px-0 resize-none focus-visible:ring-0 print:border-0 overflow-hidden bg-transparent text-slate-800"
                          onInput={(e) => {
                            const target = e.target as HTMLTextAreaElement;
                            target.style.height = 'auto';
                            target.style.height = target.scrollHeight + 'px';
                          }}
                        />
                      </td>
                      <td className="py-3 px-2 text-center align-top">
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) =>
                            updateLineItem(item.id, 'quantity', parseFloat(e.target.value) || 0)
                          }
                          className="text-sm text-center border-0 px-1 focus-visible:ring-0 print:border-0 bg-transparent w-full"
                        />
                      </td>
                      <td className="py-3 px-2 text-right align-top">
                        <Input
                          type="number"
                          value={item.rate}
                          onChange={(e) =>
                            updateLineItem(item.id, 'rate', parseFloat(e.target.value) || 0)
                          }
                          className="text-sm text-right border-0 px-1 focus-visible:ring-0 print:border-0 bg-transparent w-full"
                        />
                      </td>
                      <td className="py-3 px-2 text-right font-medium align-top text-slate-800">
                        {formatCurrency(item.quantity * item.rate)}
                      </td>
                      <td className="py-3 px-2 text-right print:hidden align-top">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeLineItem(item.id)}
                          disabled={lineItems.length === 1}
                          className="h-7 w-7 p-0"
                        >
                          <Trash2 className="size-3.5 text-slate-400 hover:text-red-500" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <Button
                onClick={addLineItem}
                variant="outline"
                className="mt-4 gap-2 print:hidden"
              >
                <Plus className="size-4" />
                {t.addItem}
              </Button>
            </div>

            {/* Totals */}
            <div className="flex justify-end mb-6">
              <div className="w-80">
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b border-slate-200">
                    <span className="text-slate-600">{t.subtotal}</span>
                    <span className="text-slate-800 font-medium">{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between py-3 bg-blue-50 px-4 rounded-lg border-l-4 border-blue-600">
                    <span className="font-bold text-slate-800 text-base">{t.totalPrice}</span>
                    <span className="font-bold text-blue-600 text-xl">{formatCurrency(subtotal)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes */}
            <div className="mb-6">
              <Label className="text-slate-600 mb-2 block text-xs font-semibold uppercase tracking-wider">{t.notes}</Label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full min-h-20 text-sm border border-slate-200 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-700 print:border-0 print:p-0 print:rounded-none"
                placeholder={t.notesPlaceholder}
              />
            </div>

            {/* Signature Section Toggle (for Offers only) */}
            {documentType === 'offer' && (
              <div className="mb-4 print:hidden">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showSignature}
                    onChange={(e) => setShowSignature(e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm text-slate-600">{t.showSignature}</span>
                </label>
              </div>
            )}

            {/* Signature */}
            {(documentType === 'invoice' || showSignature) && (
              <div className="border-t border-slate-200 pt-6 mt-6">
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <Label className="text-slate-600 mb-3 block text-xs font-semibold uppercase tracking-wider">{t.supplierSignature}</Label>
                    <div className="print:hidden mb-2">
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleSignatureUpload}
                        className="cursor-pointer text-sm border-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-600 hover:file:bg-blue-100"
                      />
                    </div>
                    {signature && (
                      <div>
                        <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
                          <img
                            src={signature}
                            alt={t.signature}
                            className="max-h-20 object-contain"
                          />
                        </div>
                        <Button
                          onClick={() => setSignature('')}
                          variant="outline"
                          size="sm"
                          className="mt-2 print:hidden text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="size-3.5 mr-2" />
                          {t.removeSignature}
                        </Button>
                      </div>
                    )}
                    {!signature && (
                      <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 h-24 flex items-center justify-center text-slate-400 text-xs">
                        {t.signatureSpace}
                      </div>
                    )}
                  </div>
                  <div></div>
                </div>
              </div>
            )}

            {/* Archive Button */}
            <div className="flex gap-2 mt-4 print:hidden">
              <Button
                onClick={archiveInvoice}
                variant="default"
                className="gap-2"
              >
                <Archive className="size-4" />
                {t.archiveInvoice}
              </Button>
              <div className="relative flex-1">
                <Button
                  onClick={() => setShowArchivedDropdown(!showArchivedDropdown)}
                  variant="outline"
                  className="gap-2 w-full"
                >
                  <FolderOpen className="size-4" />
                  {t.archivedInvoices} ({archivedInvoices.length})
                </Button>
                {showArchivedDropdown && (
                  <div className="absolute left-0 top-full mt-1 bg-white border border-slate-300 shadow-lg z-10 w-full max-h-60 overflow-y-auto rounded-md">
                    {archivedInvoices.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-slate-500 text-center">
                        {t.noArchivedInvoices}
                      </div>
                    ) : (
                      archivedInvoices.map((invoice) => (
                        <div
                          key={invoice.id}
                          className="px-4 py-3 cursor-pointer hover:bg-slate-100 flex justify-between items-center group border-b border-slate-100 last:border-0"
                          onClick={() => loadArchivedInvoice(invoice)}
                        >
                          <div className="flex-1">
                            <div className="text-sm font-medium text-slate-900">{invoice.invoiceNumber}</div>
                            <div className="text-xs text-slate-500">{invoice.clientName} • {invoice.archivedDate}</div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => deleteArchivedInvoice(invoice.id, e)}
                            className="opacity-0 group-hover:opacity-100 h-7 w-7 p-0"
                          >
                            <Trash2 className="size-3.5 text-red-500" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}